package Steps;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import WebPages.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginSteps {

	public WebDriver driver;
	public LoginPage lp;

	@Given("Launch Chrome Browser")
	public void launch_chrome_browser() {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(options);
		lp = new LoginPage(driver);

	}

	@When("Open The URL {string}")
	public void open_the_url(String url) {
		driver.get(url);
		driver.manage().window().maximize();
	}

	@When("Enter Login Credentials User as {string} and Password as {string}")
	public void enter_login_credentials_user_as_and_password_as(String uName, String pwd) {
		lp.setUserName(uName);
		lp.setPassword(pwd);
	}

	@When("Click On Login")
	public void click_on_login() {
		lp.clickOnLogin();
	}

	@Then("Page Title Should be {string}")
	public void page_title_should_be(String getTxt) {
	   Assert.assertEquals(getTxt, driver.getTitle());
	}
	
	@When("User Click on Logout Link")
	public void user_click_on_logout_link() throws InterruptedException {
		lp.clickOnLogout();
		Thread.sleep(2000);
	}

	@Then("Close Browser")
	public void close_browser() {
		driver.quit();
	}
}