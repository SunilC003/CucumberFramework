package WebPages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

	public WebDriver driver;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(id="username")
	@CacheLookup
	WebElement txtEmail;
	
	@FindBy(id="password")
	@CacheLookup
	WebElement txtPwd;
	
	@FindBy(xpath="//button[text()='Submit']")
	@CacheLookup
	WebElement btnLogin;
	
	@FindBy(linkText="Log out")
	@CacheLookup
	WebElement btnLogout	;
	
	public void setUserName(String uname) {
		txtEmail.sendKeys(uname);
	}
	
	public void setPassword(String pwd) {
		txtPwd.sendKeys(pwd);
	}
	
	public void clickOnLogin(){
		btnLogin.click();
	}
	
	public void clickOnLogout() {
		btnLogout.click();
	}
}
